PasswordStealer
===============

USB / CD / DVD autorun password stealer for Penetration Tests.

Masquerades as a virus scanner. CMD prompt pop up window displayed when launched, but outputs fake anti virus scan status. Code is well documented, feel free to modify for your own personal use.

Test in a lab environment. Use at your own risk =) 

-

Note: this project isn't being maintained. You're welcome to fork it and bring it up to date if you feel so inclined.
