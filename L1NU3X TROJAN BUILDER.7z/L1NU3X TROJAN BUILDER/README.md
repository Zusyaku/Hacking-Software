PERHATIAN:
INI HANYA UNTUK TUJUAN PENDIDIKAN SAJA JANGAN GUNAKAN INI UNTUK KEGIATAN ILEGAL SAYA TIDAK BERTANGGUNG JAWAB ATAS APA YANG ANDA LAKUKAN
=======================================
SUBSCRIBE MY CHANNEL : https://www.youtube.com/c/3XPLOITIDOFFICIAL
DONATION : https://saweria.co/MRL1NU3X
INSTAGRAM : https://www.instagram.com/3xploit.id/
=======================================