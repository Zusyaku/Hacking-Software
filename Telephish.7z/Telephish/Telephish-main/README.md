# Telephish

Phishing instagram,vk,tiktok in telegram

Phishing telegram bots Author:Telegram @lamer112311 Full documentation: 
https://telegra.ph/Sozdaem-botov-dlya-fishinga-soc-setej-07-24
