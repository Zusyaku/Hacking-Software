Contents
--------

  Program information
  Author information
  Description
  Registration
  Technical support



Program information
-------------------

Program Archive Name:
  fstmail.zip
Program Name/Title:
  1st Mass Mailer
Program Version:
  7.0
Program Release Date:
  February 1, 2013
Program Description:
  Utility for sending customized emails to subscribers and manipulations on
  the mailing lists
Target OS:
  All Windows
Software type:
  Shareware ($69, Discounts)
  http://www.softstack.com/buyfstmail.html
Program home page:
  http://www.softstack.com/fstmail.html



Author information
-------------------

Copyright:
  IM Soft, Ltd.
Contact us:
  http://www.softstack.com/contact.html
Web Site:
  http://www.softstack.com



Description                        
-----------

1st Mass Mailer is intended for sending requested email newsletters or notifications
utilizing subscription-based mailing lists. This program allows you to create
and manage a customer database and generate personalized messages from predefined
templates using a variety of data fields such as Name, Age, Gender, Address,
Country and so on. It lets you have for example order numbers, member IDs and
other data in the database along with email addresses and names and use them to
generate individual messages with order or membership status and so on. You just
use macro substitution patterns, to be replaced with information from the
database, for each customer, right before dispatching. You can also add your own
custom fields to the database if you need to have more information on each
customer. Using tab delimited or CSV format you can synchronize the program with
virtually any database system such as Microsoft Access, Excel, SQL, Oracle and so
on. You can use all the standard message formats like plain text, HTML or even
create a rich content message in the Microsoft Outlook Express and export it into
the program. The interface of the program is very simple and easy to learn - 
nearly all functions can be performed using hotkeys on the keyboard. This software
is a handy tool for keeping feedback from your customers, its a mailing list
manager, a sophisticated address book, with a built in database, and an email
program.



Registration
------------

This software is distributed as shareware. To keep the program on your
personal computer you should register it. The first step is to obtain a
registration code by paying a fee to us in the amount of $69 or with
some discounts depending on quantity of licenses(see below). You will find
all necessary information regarding registration on Order Form(see below).
The second step is to enter your registration code in the program.
Use Help-Register item of the main menu to enter the code in the program.
To avoid errors, It is recommended to use Windows Clipboard while entering
the code.

Order Form:
  http://www.softstack.com/buyfstmail.html

Discounts:
  1 license = $69
  2 licenses = $120
  5 licenses = $180
  10 licenses = $210
  15 licenses = $240
  20 licenses = $270
  25 licenses = $290
  30 licenses = $310
  40 licenses = $330
  50 licenses = $350
  60 licenses = $370
  70 licenses = $390
  80 licenses = $410
  90 licenses = $430
  100 licenses = $450
  150 licenses = $500
  200 licenses = $550
  Site license = $600



Technical support
-----------------

If you have had a problem, please, contact us using this URL:
http://www.softstack.com/contact.html
(We answer our e-mail within 12-24 hours)
Please, inform us about the following:
 - Windows version (including service packs and other fixes installed);
 - detailed description of your problem.
If the problem is a bug in our program, it will be fixed in the next version
within a month.
If you have any comments or suggestions for the next releases, please post
them to us.
