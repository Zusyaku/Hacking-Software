# RapidPayload

Framework RapidPayload - Metasploit Payload Generator 

<h3> Requirements </h3>
 
 * OpenJDK 8 (JAVA) , or superiors versions .
 
 * Metasploit
 
 * Apktool
 
 * Python3
 
 * Wine
 
<h3> Execution: </h3>

* git clone https://github.com/AngelSecurityTeam/RapidPayload

* cd RapidPayload

* bash install.sh

* python3 RapidPayload.py

<h3> Linux: </h3>

* Kali Linux

* Parrot Security OS

* BlackArch Linux

* BackBox

* Bugtraq

* ArhStrike

* Cyborg Linux

* Matriux

* Demon Linux

* Tsurugi Linux

<h3>AngelSecurityTeam</h3>

<img src="https://github.com/AngelSecurityTeam/RapidPayload/blob/master/Image/NewV.png">

<img src="https://github.com/AngelSecurityTeam/RapidPayload/blob/master/Image/Fnew.png">

<img src="https://github.com/AngelSecurityTeam/RapidPayload/blob/master/Image/Android.png">

<img src="https://github.com/AngelSecurityTeam/RapidPayload/blob/master/Image/linux.png">

<img src="https://github.com/AngelSecurityTeam/RapidPayload/blob/master/Image/ngrok_py.png">

<h3> Paypal Donations: </h3>

* https://www.paypal.com/paypalme/AngelSecTeam
