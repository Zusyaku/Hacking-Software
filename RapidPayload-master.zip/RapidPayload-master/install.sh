#https://github.com/AngelSecurityTeam
pip3 install -r requirements.txt
python3 Server.py
sudo chmod +x RapidPayload.py
var=$(pwd)
cd  $var"/Image/"
unzip Hyperion.zip
rm -rf Hyperion.zip
cd ..
apt-get install wine # install default  [ wine ]| [ wine64 ]
apt-get install osslsigncode # osslsigncode
